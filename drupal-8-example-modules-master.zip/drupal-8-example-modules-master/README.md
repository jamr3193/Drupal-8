# drupal-8-example-modules

* `hello_world` has been tested successfully

* `links_and_tables` has been tested successfully

* `page_css` is not working properly

* `my_menu` is not working properly

* `sum_by_url` has been tested successfully
